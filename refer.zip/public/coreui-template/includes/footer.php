      <footer class="footer px-4">
        <div>
          <a href="https://coreui.io">CoreUI </a
          ><a href="https://coreui.io/product/bootstrap-dashboard-template/"
            >Bootstrap Admin Template</a
          >
          © 2025 creativeLabs.
        </div>
        <div class="ms-auto">
          Powered by&nbsp;<a href="https://coreui.io/bootstrap/docs/"
            >CoreUI PRO UI Components</a
          >
        </div>
      </footer>