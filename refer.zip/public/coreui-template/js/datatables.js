/* global $ */
/**
 * --------------------------------------------------------------------------
 * CoreUI PRO Boostrap Admin Template datatables.js
 * License (https://coreui.io/pro/license/)
 * --------------------------------------------------------------------------
 */
$(document).ready(() => {
  $('.datatable').DataTable();
  $('.datatable').attr('style', 'border-collapse: collapse !important');
});
//# sourceMappingURL=datatables.js.map