<?php $__env->startSection('title', 'User Management'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<div class="card mb-4">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="card-title mb-0">
                    <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-people')); ?>"></use>
                    </svg>
                    User Management
                </h4>
                <p class="text-body-secondary mb-0">Manage system users and their roles</p>
            </div>
            <div>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary">
                    <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-arrow-left')); ?>"></use>
                    </svg>
                    Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<!-- User Statistics -->
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
        <div class="card text-white bg-primary-gradient">
            <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                <div>
                    <div class="fs-4 fw-semibold"><?php echo e($users->total()); ?></div>
                    <div>Total Users</div>
                </div>
                <svg class="icon icon-3xl">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-people')); ?>"></use>
                </svg>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card text-white bg-success-gradient">
            <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                <div>
                    <div class="fs-4 fw-semibold"><?php echo e($users->where('email_verified_at', '!=', null)->count()); ?></div>
                    <div>Verified Users</div>
                </div>
                <svg class="icon icon-3xl">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check')); ?>"></use>
                </svg>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card text-white bg-warning-gradient">
            <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                <div>
                    <div class="fs-4 fw-semibold"><?php echo e($users->where('two_factor_secret', '!=', null)->count()); ?></div>
                    <div>2FA Enabled</div>
                </div>
                <svg class="icon icon-3xl">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-lock-locked')); ?>"></use>
                </svg>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card text-white bg-info-gradient">
            <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                <div>
                    <div class="fs-4 fw-semibold"><?php echo e($users->filter(function($user) { return $user->hasRole('admin'); })->count()); ?></div>
                    <div>Administrators</div>
                </div>
                <svg class="icon icon-3xl">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-shield-alt')); ?>"></use>
                </svg>
            </div>
        </div>
    </div>
</div>

<!-- Users List -->
<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <svg class="icon me-2">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-list')); ?>"></use>
                </svg>
                <strong>All Users</strong>
                <small class="text-body-secondary ms-2">A list of all users in the system including their roles and status.</small>
            </div>
            <?php if (isset($component)) { $__componentOriginal720c5d99204acad589a79c73de989541 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal720c5d99204acad589a79c73de989541 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.per-page-selector','data' => ['perPage' => $perPage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('per-page-selector'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['perPage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($perPage)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal720c5d99204acad589a79c73de989541)): ?>
<?php $attributes = $__attributesOriginal720c5d99204acad589a79c73de989541; ?>
<?php unset($__attributesOriginal720c5d99204acad589a79c73de989541); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal720c5d99204acad589a79c73de989541)): ?>
<?php $component = $__componentOriginal720c5d99204acad589a79c73de989541; ?>
<?php unset($__componentOriginal720c5d99204acad589a79c73de989541); ?>
<?php endif; ?>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th scope="col">User</th>
                        <th scope="col">Email</th>
                        <th scope="col">Roles</th>
                        <th scope="col">Status</th>
                        <th scope="col">Created</th>
                        <th scope="col" class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar me-3 bg-primary">
                                        <span class="text-white"><?php echo e(strtoupper(substr($user->fullname ?? $user->username, 0, 2))); ?></span>
                                    </div>
                                    <div>
                                        <div class="fw-semibold"><?php echo e($user->fullname ?? $user->username); ?></div>
                                        <div class="text-body-secondary">ID: <?php echo e($user->id); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="fw-semibold"><?php echo e($user->email); ?></div>
                                <?php if($user->email_verified_at): ?>
                                    <div class="text-success small">
                                        <svg class="icon me-1">
                                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check')); ?>"></use>
                                        </svg>
                                        Verified
                                    </div>
                                <?php else: ?>
                                    <div class="text-danger small">
                                        <svg class="icon me-1">
                                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-x')); ?>"></use>
                                        </svg>
                                        Not Verified
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="d-flex flex-wrap gap-1">
                                    <?php $__empty_1 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <span class="badge <?php echo e($role->name === 'admin' ? 'bg-danger' : 'bg-primary'); ?>">
                                            <?php echo e(ucfirst($role->name)); ?>

                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <span class="text-body-secondary">No roles assigned</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <?php if($user->two_factor_secret): ?>
                                    <span class="badge bg-success">
                                        <svg class="icon me-1">
                                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-lock-locked')); ?>"></use>
                                        </svg>
                                        2FA Enabled
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-warning">
                                        <svg class="icon me-1">
                                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-lock-unlocked')); ?>"></use>
                                        </svg>
                                        2FA Disabled
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="fw-semibold"><?php echo e($user->created_at->format('M d, Y')); ?></div>
                                <div class="text-body-secondary small"><?php echo e($user->created_at->format('g:i A')); ?></div>
                            </td>
                            <td class="text-center">
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-sm btn-outline-primary">
                                        <svg class="icon me-1">
                                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-pencil')); ?>"></use>
                                        </svg>
                                        Edit
                                    </a>
                                    <?php if (! ($user->hasRole('admin'))): ?>
                                        <?php if($user->wallet && $user->wallet->is_active): ?>
                                            <button onclick="suspendUser(<?php echo e($user->id); ?>)" class="btn btn-sm btn-outline-warning">
                                                <svg class="icon me-1">
                                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-lock-locked')); ?>"></use>
                                                </svg>
                                                Suspend
                                            </button>
                                        <?php else: ?>
                                            <button onclick="activateUser(<?php echo e($user->id); ?>)" class="btn btn-sm btn-outline-success">
                                                <svg class="icon me-1">
                                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-lock-unlocked')); ?>"></use>
                                                </svg>
                                                Activate
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($users->hasPages()): ?>
        <div class="card-footer">
            <?php echo e($users->links()); ?>

        </div>
    <?php endif; ?>
</div>

<!-- Bottom spacing for better visual layout -->
<div class="pb-5"></div>

<!-- Suspend Confirmation Modal -->
<div class="modal fade" id="suspendModal" tabindex="-1" aria-labelledby="suspendModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning bg-opacity-10">
                <h5 class="modal-title text-warning" id="suspendModalLabel">
                    <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-warning')); ?>"></use>
                    </svg>
                    Suspend User Account
                </h5>
                <button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="mb-0">Are you sure you want to suspend this user? They will not be able to access their account.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-coreui-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-warning" id="confirmSuspendBtn">Suspend User</button>
            </div>
        </div>
    </div>
</div>

<!-- Activate Confirmation Modal -->
<div class="modal fade" id="activateModal" tabindex="-1" aria-labelledby="activateModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success bg-opacity-10">
                <h5 class="modal-title text-success" id="activateModalLabel">
                    <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check-circle')); ?>"></use>
                    </svg>
                    Activate User Account
                </h5>
                <button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="mb-0">Are you sure you want to activate this user? Their account will be reactivated.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-coreui-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-success" id="confirmActivateBtn">Activate User</button>
            </div>
        </div>
    </div>
</div>

<!-- Success/Error Toast -->
<div class="toast-container position-fixed top-0 end-0 p-3">
    <div id="actionToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header">
            <svg class="icon me-2" id="toastIcon">
                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check-circle')); ?>"></use>
            </svg>
            <strong class="me-auto" id="toastTitle">Success</strong>
            <button type="button" class="btn-close" data-coreui-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body" id="toastMessage"></div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
let currentUserId = null;

function suspendUser(userId) {
    currentUserId = userId;
    const modal = new coreui.Modal(document.getElementById('suspendModal'));
    modal.show();
}

function activateUser(userId) {
    currentUserId = userId;
    const modal = new coreui.Modal(document.getElementById('activateModal'));
    modal.show();
}

document.getElementById('confirmSuspendBtn').addEventListener('click', function() {
    performAction('suspend');
});

document.getElementById('confirmActivateBtn').addEventListener('click', function() {
    performAction('activate');
});

function performAction(action) {
    const modal = coreui.Modal.getInstance(document.getElementById(action === 'suspend' ? 'suspendModal' : 'activateModal'));
    modal.hide();

    fetch(`/admin/users/${currentUserId}/${action}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Success', data.message, 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            showToast('Error', data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('Error', `An error occurred while ${action === 'suspend' ? 'suspending' : 'activating'} the user`, 'error');
    });
}

function showToast(title, message, type) {
    const toast = document.getElementById('actionToast');
    const toastTitle = document.getElementById('toastTitle');
    const toastMessage = document.getElementById('toastMessage');
    const toastIcon = document.getElementById('toastIcon').querySelector('use');

    toastTitle.textContent = title;
    toastMessage.textContent = message;

    const toastHeader = toast.querySelector('.toast-header');
    toastHeader.className = 'toast-header';

    if (type === 'success') {
        toastHeader.classList.add('bg-success', 'text-white');
        toastIcon.setAttribute('xlink:href', "<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check-circle')); ?>");
    } else {
        toastHeader.classList.add('bg-danger', 'text-white');
        toastIcon.setAttribute('xlink:href', "<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-x-circle')); ?>");
    }

    const bsToast = new coreui.Toast(toast);
    bsToast.show();
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\coreui_laravel_deploy\resources\views/admin/users.blade.php ENDPATH**/ ?>