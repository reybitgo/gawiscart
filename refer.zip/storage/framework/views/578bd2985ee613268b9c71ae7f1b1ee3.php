<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 d-flex flex-row align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card-group d-block d-md-flex row">
                    <div class="card col-md-7 p-4 mb-0">
                        <div class="card-body">
                            <div class="text-center mb-4">
                                <img class="logo-dark" src="<?php echo e(asset('coreui-template/assets/brand/gawis_logo.png')); ?>" width="110" height="39" alt="<?php echo e(config('app.name', 'Gawis iHerbal')); ?> Logo" />
                                <img class="logo-light" src="<?php echo e(asset('coreui-template/assets/brand/gawis_logo_light.png')); ?>" width="110" height="39" alt="<?php echo e(config('app.name', 'Gawis iHerbal')); ?> Logo" />
                            </div>
                            <h1>Login</h1>
                            <p class="text-body-secondary">Sign In to your account</p>

                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>


                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger d-flex align-items-start">
                                    <svg class="icon icon-lg me-2 flex-shrink-0 mt-1">
                                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-warning')); ?>"></use>
                                    </svg>
                                    <div>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div><?php echo e($error); ?></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <form action="<?php echo e(route('login')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="input-group mb-3">
                                    <span class="input-group-text">
                                        <svg class="icon">
                                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-user')); ?>"></use>
                                        </svg>
                                    </span>
                                    <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           type="text"
                                           name="email"
                                           id="email"
                                           placeholder="Email address or Username"
                                           value="<?php echo e(old('email')); ?>"
                                           autocomplete="email"
                                           required>
                                </div>

                                <div class="input-group mb-4">
                                    <span class="input-group-text">
                                        <svg class="icon">
                                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-lock-locked')); ?>"></use>
                                        </svg>
                                    </span>
                                    <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           type="password"
                                           name="password"
                                           id="password"
                                           placeholder="Password"
                                           autocomplete="current-password"
                                           required>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-6">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="showPassword">
                                            <label class="form-check-label" for="showPassword">
                                                Show password
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="remember" id="remember">
                                            <label class="form-check-label" for="remember">
                                                Remember me
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-6">
                                        <button class="btn btn-primary px-4" type="submit">Login</button>
                                    </div>
                                    <div class="col-6 text-end">
                                        <a href="<?php echo e(route('password.request')); ?>" class="btn btn-link px-0">Forgot password?</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card col-md-5 text-white bg-primary py-5">
                        <div class="card-body text-center">
                            <div>
                                <h2>Sign up</h2>
                                <p>Join our secure E-Wallet platform and manage your digital transactions with confidence and ease.</p>
                                <a href="<?php echo e(route('register')); ?>" class="btn btn-lg btn-outline-light mt-3">Register Now!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php if(session('success') || session('error')): ?>
<div class="modal fade" id="resetModal" tabindex="-1" aria-labelledby="resetModalLabel" aria-hidden="true" data-coreui-backdrop="static" data-coreui-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <?php if(session('success')): ?>
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="resetModalLabel">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check-circle')); ?>"></use>
                        </svg>
                        Database Reset Successful
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-coreui-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3"><?php echo e(session('success')); ?></p>

                    <?php if(session('reset_info')): ?>
                        <div class="alert alert-info mb-0">
                            <h6 class="alert-heading">
                                <svg class="icon me-1">
                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-user')); ?>"></use>
                                </svg>
                                Default Credentials
                            </h6>
                            <hr>
                            <div class="mb-2">
                                <span class="badge bg-primary me-2">Admin</span>
                                <code class="text-dark">admin@gawisherbal.com</code>
                                <span class="mx-1">/</span>
                                <code class="text-dark">Admin123!@#</code>
                            </div>
                            <div>
                                <span class="badge bg-info me-2">Member</span>
                                <code class="text-dark">member@gawisherbal.com</code>
                                <span class="mx-1">/</span>
                                <code class="text-dark">Member123!@#</code>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" data-coreui-dismiss="modal">Got it!</button>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="resetModalLabel">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-x-circle')); ?>"></use>
                        </svg>
                        Database Reset Failed
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-coreui-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-danger mb-0">
                        <h6 class="alert-heading">Error Details:</h6>
                        <p class="mb-0"><?php echo e(session('error')); ?></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-coreui-dismiss="modal">Close</button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const showPasswordCheckbox = document.getElementById('showPassword');
    const passwordInput = document.getElementById('password');

    // Function to toggle password visibility
    function togglePasswordVisibility() {
        const inputType = showPasswordCheckbox.checked ? 'text' : 'password';
        passwordInput.type = inputType;
    }

    // Listen for checkbox changes
    showPasswordCheckbox.addEventListener('change', togglePasswordVisibility);

    // Auto-show reset modal if session has reset info
    <?php if(session('success') || session('error')): ?>
        const resetModal = document.getElementById('resetModal');
        if (resetModal) {
            const modal = new coreui.Modal(resetModal);
            modal.show();
        }
    <?php endif; ?>
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\coreui_laravel_deploy\resources\views/auth/login.blade.php ENDPATH**/ ?>