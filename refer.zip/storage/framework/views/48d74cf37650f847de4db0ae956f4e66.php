<header class="header header-sticky p-0 mb-4">
    <div class="container-fluid px-4 border-bottom">
        <button class="header-toggler" type="button" onclick='coreui.Sidebar.getInstance(document.querySelector("#sidebar")).toggle()' style="margin-inline-start: -14px">
            <svg class="icon icon-lg">
                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-menu')); ?>"></use>
            </svg>
        </button>
        <ul class="header-nav d-none d-md-flex">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            </li>
            <?php if(auth()->user()->hasRole('admin')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin.users')); ?>">Users</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin.system.settings')); ?>">Settings</a>
            </li>
            <?php endif; ?>
        </ul>
        <ul class="header-nav ms-auto">
            <!-- Cart Icon with Dropdown -->
            <li class="nav-item dropdown">
                <a class="nav-link position-relative" data-coreui-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" title="Shopping Cart">
                    <svg class="icon icon-lg">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-basket')); ?>"></use>
                    </svg>
                    <span id="cart-count" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.7rem; <?php echo e($globalCartCount > 0 ? '' : 'display: none;'); ?>">
                        <?php echo e($globalCartCount); ?>

                    </span>
                </a>
                <div class="dropdown-menu dropdown-menu-end pt-0" style="width: 350px; max-height: 400px; overflow-y: auto;">
                    <div id="cart-dropdown-content">
                        <?php if($globalCartCount > 0): ?>
                            <div class="dropdown-header bg-light fw-semibold text-dark border-bottom">
                                Cart (<?php echo e($globalCartCount); ?> items)
                            </div>
                            <?php $__currentLoopData = $globalCartSummary['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="dropdown-item-text border-bottom p-3">
                                    <div class="d-flex align-items-center">
                                        <img src="<?php echo e($item['image_url']); ?>" alt="<?php echo e($item['name']); ?>" class="rounded me-3" style="width: 40px; height: 40px; object-fit: cover;">
                                        <div class="flex-grow-1">
                                            <div class="fw-semibold small"><?php echo e(Str::limit($item['name'], 25)); ?></div>
                                            <div class="text-muted small">
                                                <?php echo e($item['quantity']); ?> × $<?php echo e(number_format($item['price'], 2)); ?>

                                            </div>
                                        </div>
                                        <div class="text-end">
                                            <div class="fw-semibold small">$<?php echo e(number_format($item['price'] * $item['quantity'], 2)); ?></div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="dropdown-header bg-light border-bottom">
                                <div class="d-flex justify-content-between">
                                    <span>Total:</span>
                                    <span class="fw-bold">$<?php echo e(number_format($globalCartSummary['total'], 2)); ?></span>
                                </div>
                            </div>
                            <div class="dropdown-item-text p-3">
                                <div class="d-grid gap-2">
                                    <a href="<?php echo e(route('cart.index')); ?>" class="btn btn-primary btn-sm">
                                        <svg class="icon me-2">
                                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-basket')); ?>"></use>
                                        </svg>
                                        View Cart
                                    </a>
                                    <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-outline-primary btn-sm">
                                        <svg class="icon me-2">
                                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-credit-card')); ?>"></use>
                                        </svg>
                                        Checkout
                                    </a>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="dropdown-item-text text-center p-4">
                                <svg class="icon icon-xl text-muted mb-2">
                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-basket')); ?>"></use>
                                </svg>
                                <div class="text-muted small mb-3">Your cart is empty</div>
                                <a href="<?php echo e(route('packages.index')); ?>" class="btn btn-primary btn-sm">
                                    Browse Packages
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </li>
            <!-- Username Display -->
            <li class="nav-item">
                <span class="nav-link px-2 text-body-secondary">
                    <?php echo e(auth()->user()->username); ?>

                </span>
            </li>
            <!-- User Profile -->
            <li class="nav-item dropdown">
                <a class="nav-link py-0 pe-0" data-coreui-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <div class="avatar rounded-circle" style="width: 32px; height: 32px;">
                        <div class="avatar-img bg-primary text-white d-flex align-items-center justify-content-center rounded-circle" style="width: 32px; height: 32px;">
                            <svg class="icon" style="width: 18px; height: 18px;">
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-user')); ?>"></use>
                            </svg>
                        </div>
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-end pt-0 w-auto">
                    <a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-user')); ?>"></use>
                        </svg>
                        <span>Profile</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item">
                            <svg class="icon me-2">
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-account-logout')); ?>"></use>
                            </svg>
                            <span>Logout</span>
                        </button>
                    </form>
                </div>
            </li>
        </ul>
    </div>
    <div class="container-fluid px-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb my-0">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('dashboard')); ?>">Home</a>
                </li>
                <?php if(isset($breadcrumbs) && count($breadcrumbs) > 0): ?>
                    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($breadcrumb['url']) && !$loop->last): ?>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e($breadcrumb['url']); ?>"><?php echo e($breadcrumb['title']); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="breadcrumb-item active">
                                <span><?php echo e($breadcrumb['title']); ?></span>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <li class="breadcrumb-item active">
                        <span><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></span>
                    </li>
                <?php endif; ?>
            </ol>
        </nav>
    </div>
</header><?php /**PATH C:\laragon\www\coreui_laravel_deploy\resources\views/partials/header.blade.php ENDPATH**/ ?>