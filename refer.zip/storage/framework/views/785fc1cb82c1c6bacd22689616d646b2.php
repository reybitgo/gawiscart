<?php $__env->startSection('title', 'Transfer Funds'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<div class="card mb-4">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="card-title mb-0">
                    <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-swap-horizontal')); ?>"></use>
                    </svg>
                    Transfer Funds
                </h4>
                <p class="text-body-secondary mb-0">Send funds to another user</p>
            </div>
            <div>
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">
                    <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-arrow-left')); ?>"></use>
                    </svg>
                    Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Current Balance Card -->
<div class="row mb-4">
    <div class="col-md-6 mx-auto">
        <div class="card bg-success-gradient text-white">
            <div class="card-body text-center">
                <h5 class="card-title">Available Balance (Transferable)</h5>
                <h2 class="display-4 fw-bold"><?php echo e(currency($wallet->purchase_balance)); ?></h2>
                <p class="mb-0">
                    <span class="badge <?php echo e($wallet->is_active ? 'bg-light text-success' : 'bg-danger'); ?>">
                        <?php echo e($wallet->is_active ? 'Account Active' : 'Account Frozen'); ?>

                    </span>
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Recent Recipients -->
<?php if($frequentRecipients->count() > 0): ?>
<div class="row mb-4">
    <div class="col-md-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <svg class="icon me-2">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-people')); ?>"></use>
                </svg>
                <strong>Frequent Recipients</strong>
                <small class="text-body-secondary ms-auto">Your most frequent transfer recipients</small>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                    <?php $__currentLoopData = $frequentRecipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="btn btn-outline-secondary btn-sm"
                                onclick="setRecipient('<?php echo e($recipient->username ?: $recipient->email); ?>')"
                                title="Transferred <?php echo e($recipient->transfer_count); ?> time(s) - Last: <?php echo e(\Carbon\Carbon::parse($recipient->last_transfer_at)->diffForHumans()); ?>">
                            <svg class="icon me-1">
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-user')); ?>"></use>
                            </svg>
                            <?php echo e($recipient->fullname ?: ($recipient->username ?: $recipient->email)); ?>

                            <span class="badge bg-primary ms-1"><?php echo e($recipient->transfer_count); ?></span>
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="text-center mt-2">
                    <small class="text-body-secondary">Click to quickly select a recipient • Numbers show transfer count</small>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Quick Amount Buttons -->
<div class="row mb-4">
    <div class="col-md-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <svg class="icon me-2">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-speedometer')); ?>"></use>
                </svg>
                <strong>Quick Amounts</strong>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                    <?php $__currentLoopData = [10, 25, 50, 100, 250, 500]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quickAmount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($wallet->purchase_balance >= $quickAmount): ?>
                            <button type="button" class="btn btn-outline-primary" onclick="setAmount(<?php echo e($quickAmount); ?>)">
                                <?php echo e(currency_symbol()); ?><?php echo e($quickAmount); ?>

                            </button>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Alert Messages -->
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <svg class="icon me-2">
            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check')); ?>"></use>
        </svg>
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-coreui-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <svg class="icon me-2">
            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-x')); ?>"></use>
        </svg>
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <button type="button" class="btn-close" data-coreui-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Transfer Form -->
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <svg class="icon me-2">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-swap-horizontal')); ?>"></use>
                </svg>
                <strong>Transfer Form</strong>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('wallet.transfer.process')); ?>" id="transfer-form">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="recipient_identifier" class="form-label">
                                    <svg class="icon me-2">
                                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-envelope-open')); ?>"></use>
                                    </svg>
                                    Recipient Email or Username
                                </label>
                                <input type="text" name="recipient_identifier" id="recipient_identifier" class="form-control"
                                       placeholder="recipient@example.com or username" required
                                       value="<?php echo e(old('recipient_identifier')); ?>">
                                <div class="form-text">
                                    Enter the email address or username of the recipient
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="amount" class="form-label">
                                    <svg class="icon me-2">
                                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-arrow-thick-right')); ?>"></use>
                                    </svg>
                                    Transfer Amount
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text"><?php echo e(currency_symbol()); ?></span>
                                    <input type="number" name="amount" id="amount" class="form-control"
                                           placeholder="0.00" min="1" max="<?php echo e(min($wallet->purchase_balance, 10000)); ?>" step="0.01" required
                                           value="<?php echo e(old('amount')); ?>">
                                    <span class="input-group-text"><?php echo e(currency_code()); ?></span>
                                </div>
                                <div class="form-text">
                                    Minimum: <?php echo e(currency(1)); ?> | Maximum: <?php echo e(currency(min($wallet->purchase_balance, 10000))); ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="note" class="form-label">
                            <svg class="icon me-2">
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-notes')); ?>"></use>
                            </svg>
                            Transfer Note (Optional)
                        </label>
                        <textarea name="note" id="note" rows="3" class="form-control"
                                  placeholder="What's this transfer for?" maxlength="255"><?php echo e(old('note')); ?></textarea>
                        <div class="form-text">
                            Add a note to help identify this transfer (optional)
                        </div>
                    </div>

                    <!-- Transfer Summary -->
                    <div id="transfer-fee-info" class="card bg-info-subtle border-info mb-3 d-none">
                        <div class="card-body">
                            <h6 class="card-title">
                                <svg class="icon me-2">
                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-calculator')); ?>"></use>
                                </svg>
                                Transfer Summary
                            </h6>
                            <div class="row text-center">
                                <div class="col-4">
                                    <div class="text-body-secondary small">Transfer Amount</div>
                                    <div class="fw-bold" id="transfer-amount-display"><?php echo e(currency_symbol()); ?>0.00</div>
                                </div>
                                <div class="col-4">
                                    <div class="text-body-secondary small">Transfer Fee</div>
                                    <div class="fw-bold text-warning" id="transfer-fee-display"><?php echo e(currency_symbol()); ?>0.00</div>
                                </div>
                                <div class="col-4">
                                    <div class="text-body-secondary small">Total Deducted</div>
                                    <div class="fw-bold text-primary" id="total-amount-display"><?php echo e(currency_symbol()); ?>0.00</div>
                                </div>
                            </div>
                            <hr>
                            <p class="small mb-0 text-info">
                                <svg class="icon me-1">
                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-info')); ?>"></use>
                                </svg>
                                <strong>Note:</strong> Transfer will be processed instantly once confirmed.
                            </p>
                        </div>
                    </div>

                    <!-- Important Information -->
                    <div class="alert alert-warning">
                        <h6 class="alert-heading">
                            <svg class="icon me-2">
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-warning')); ?>"></use>
                            </svg>
                            Important Information
                        </h6>
                        <ul class="mb-0">
                            <li>Transfers are processed instantly upon confirmation</li>
                            <li>Please verify the recipient email or username carefully</li>
                            <li>Transfer fees are deducted from your wallet immediately</li>
                            <li>Completed transfers cannot be reversed</li>
                        </ul>
                    </div>

                    <div class="d-grid gap-2 d-md-flex">
                        <button type="submit" class="btn btn-success btn-lg flex-md-fill"
                                <?php echo e(!$wallet->is_active || $wallet->purchase_balance <= 0 ? 'disabled' : ''); ?>>
                            <svg class="icon me-2">
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-send')); ?>"></use>
                            </svg>
                            Send Transfer
                        </button>
                        <a href="<?php echo e(route('wallet.transactions')); ?>" class="btn btn-outline-secondary">
                            <svg class="icon me-2">
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-list')); ?>"></use>
                            </svg>
                            View Transactions
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Bottom spacing for better visual layout -->
<div class="pb-5"></div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Transfer settings from server
    const transferSettings = <?php echo json_encode($transferSettings, 15, 512) ?>;

    // Debug: Log transfer settings to console
    console.log('Transfer Settings:', transferSettings);

    function setRecipient(email) {
        document.getElementById('recipient_identifier').value = email;
        document.getElementById('recipient_identifier').focus();
    }

    function setAmount(amount) {
        document.getElementById('amount').value = amount;
        updateTransferSummary();
    }

    function calculateTransferFee(amount) {
        // These values are loaded from system settings
        const chargeEnabled = transferSettings.charge_enabled;
        const chargeType = transferSettings.charge_type;
        const chargeValue = transferSettings.charge_value;
        const minCharge = transferSettings.minimum_charge;
        const maxCharge = transferSettings.maximum_charge;

        if (!chargeEnabled || amount <= 0) {
            return 0;
        }

        let charge;
        if (chargeType === 'percentage') {
            charge = (amount * chargeValue) / 100;
        } else {
            charge = chargeValue;
        }

        // Apply minimum limit
        charge = Math.max(charge, minCharge);

        // Apply maximum limit (0 means no limit)
        if (maxCharge > 0) {
            charge = Math.min(charge, maxCharge);
        }

        return Math.round(charge * 100) / 100; // Round to 2 decimal places
    }

    function updateTransferSummary() {
        const amountInput = document.getElementById('amount');
        const amount = parseFloat(amountInput.value) || 0;

        if (amount > 0) {
            const fee = calculateTransferFee(amount);
            const total = amount + fee;

            document.getElementById('transfer-amount-display').textContent = '<?php echo e(currency_symbol()); ?>' + amount.toFixed(2);
            document.getElementById('transfer-fee-display').textContent = '<?php echo e(currency_symbol()); ?>' + fee.toFixed(2);
            document.getElementById('total-amount-display').textContent = '<?php echo e(currency_symbol()); ?>' + total.toFixed(2);
            document.getElementById('transfer-fee-info').classList.remove('d-none');
        } else {
            document.getElementById('transfer-fee-info').classList.add('d-none');
        }
    }

    // Add event listeners
    document.addEventListener('DOMContentLoaded', function() {
        const amountInput = document.getElementById('amount');
        amountInput.addEventListener('input', updateTransferSummary);
        amountInput.addEventListener('change', updateTransferSummary);

    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\coreui_laravel_deploy\resources\views/member/transfer.blade.php ENDPATH**/ ?>