<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<!-- Welcome Header -->
<div class="card mb-4 border-0 shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="card-title mb-0">Welcome back, <?php echo e($user->username); ?>! 👋</h4>
                <p class="text-body-secondary mb-0">Here's what's happening with your wallet today.</p>
            </div>
            <div class="d-none d-md-block">
                <?php if($user->hasRole('admin')): ?>
                    <span class="badge bg-purple-gradient text-white">Administrator</span>
                <?php elseif($user->hasRole('member')): ?>
                    <span class="badge bg-info-gradient text-white">Member</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Wallet Overview Cards -->
<div class="row g-3 mb-4">
    <!-- Current Balance -->
    <div class="col-sm-6 col-xl-3">
        <div class="card text-white bg-success-gradient">
            <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                <div>
                    <div class="fs-4 fw-semibold"><?php echo e(currency($wallet->total_balance)); ?></div>
                    <div>Current Balance</div>
                </div>
                <svg class="icon icon-3xl">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-wallet')); ?>"></use>
                </svg>
            </div>
        </div>
    </div>

    <!-- Total Deposits -->
    <div class="col-sm-6 col-xl-3">
        <div class="card text-white bg-info-gradient">
            <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                <div>
                    <div class="fs-4 fw-semibold"><?php echo e(currency($totalDeposits)); ?></div>
                    <div>Total Deposits</div>
                </div>
                <svg class="icon icon-3xl">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-arrow-circle-bottom')); ?>"></use>
                </svg>
            </div>
        </div>
    </div>

    <!-- Total Withdrawals -->
    <div class="col-sm-6 col-xl-3">
        <div class="card text-white bg-warning-gradient">
            <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                <div>
                    <div class="fs-4 fw-semibold"><?php echo e(currency($totalWithdrawals)); ?></div>
                    <div>Total Withdrawals</div>
                </div>
                <svg class="icon icon-3xl">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-arrow-circle-top')); ?>"></use>
                </svg>
            </div>
        </div>
    </div>

    <!-- Points Earned -->
    <div class="col-sm-6 col-xl-3">
        <div class="card text-white bg-purple-gradient">
            <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                <div>
                    <div class="fs-4 fw-semibold"><?php echo e(number_format($totalPointsEarned)); ?></div>
                    <div>Points Earned</div>
                    <?php if($pendingPoints > 0): ?>
                        <small class="opacity-75"><?php echo e(number_format($pendingPoints)); ?> pending</small>
                    <?php endif; ?>
                </div>
                <svg class="icon icon-3xl">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-star')); ?>"></use>
                </svg>
            </div>
        </div>
    </div>
</div>

<!-- MLM Balance Widget -->
<div class="row g-3 mb-4">
    <div class="col-lg-6">
        <?php echo $__env->make('components.mlm-balance-widget', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <div class="col-lg-6">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h6 class="mb-0">
                    <i class="cil-people"></i> MLM Network Stats
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-6 mb-3">
                        <label class="text-muted small">Direct Referrals</label>
                        <h4 class="mb-0"><?php echo e(auth()->user()->referrals()->count()); ?></h4>
                    </div>
                    <div class="col-6 mb-3">
                        <label class="text-muted small">Total Earnings</label>
                        <h4 class="mb-0 text-success"><?php echo e(currency(auth()->user()->wallet->mlm_balance ?? 0)); ?></h4>
                    </div>
                </div>
                <hr>
                <div class="d-flex justify-content-between">
                    <a href="<?php echo e(route('referral.index')); ?>" class="btn btn-sm btn-outline-primary">
                        <i class="cil-share"></i> My Referral Link
                    </a>
                    <a href="<?php echo e(route('member.register.show')); ?>" class="btn btn-sm btn-primary">
                        <i class="cil-user-plus"></i> Register Member
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="card-title mb-0">Quick Actions</h5>
        <div class="card-header-actions">
            <small class="text-body-secondary">Manage your wallet and transactions</small>
        </div>
    </div>
    <div class="card-body">
        <div class="row g-3">
            <?php if($user->hasRole('admin')): ?>
                <!-- Admin Actions -->
                <div class="col-md-3 col-sm-6">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-purple w-100">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-chart-pie')); ?>"></use>
                        </svg>
                        Admin Dashboard
                    </a>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('wallet_management')): ?>
                <div class="col-md-3 col-sm-6">
                    <a href="<?php echo e(route('admin.wallet.management')); ?>" class="btn btn-info w-100">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-wallet')); ?>"></use>
                        </svg>
                        Wallet Management
                    </a>
                </div>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transaction_approval')): ?>
                <div class="col-md-3 col-sm-6">
                    <a href="<?php echo e(route('admin.transaction.approval')); ?>" class="btn btn-warning w-100">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-task')); ?>"></use>
                        </svg>
                        Transaction Approval
                    </a>
                </div>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('system_settings')): ?>
                <div class="col-md-3 col-sm-6">
                    <a href="<?php echo e(route('admin.system.settings')); ?>" class="btn btn-secondary w-100">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-settings')); ?>"></use>
                        </svg>
                        System Settings
                    </a>
                </div>
                <?php endif; ?>
            <?php else: ?>
                <!-- Member Actions -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deposit_funds')): ?>
                <div class="col-md-3 col-sm-6">
                    <a href="<?php echo e(route('wallet.deposit')); ?>" class="btn btn-success w-100">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-arrow-circle-bottom')); ?>"></use>
                        </svg>
                        Deposit Funds
                    </a>
                </div>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transfer_funds')): ?>
                <div class="col-md-3 col-sm-6">
                    <a href="<?php echo e(route('wallet.transfer')); ?>" class="btn btn-info w-100">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-arrow-right')); ?>"></use>
                        </svg>
                        Transfer Funds
                    </a>
                </div>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transfer_funds')): ?>
                <div class="col-md-3 col-sm-6">
                    <a href="<?php echo e(route('wallet.convert')); ?>" class="btn btn-purple w-100">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-swap-vertical')); ?>"></use>
                        </svg>
                        Convert Balance
                    </a>
                </div>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('withdraw_funds')): ?>
                <div class="col-md-3 col-sm-6">
                    <a href="<?php echo e(route('wallet.withdraw')); ?>" class="btn btn-danger w-100">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-arrow-circle-top')); ?>"></use>
                        </svg>
                        Withdraw Funds
                    </a>
                </div>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_transactions')): ?>
                <div class="col-md-3 col-sm-6">
                    <a href="<?php echo e(route('wallet.transactions')); ?>" class="btn btn-outline-primary w-100">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-list-numbered')); ?>"></use>
                        </svg>
                        View Transactions
                    </a>
                </div>
                <?php endif; ?>
                <div class="col-md-3 col-sm-6">
                    <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-outline-secondary w-100">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-list')); ?>"></use>
                        </svg>
                        Order History
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Recent Transactions -->
<div class="card mb-4">
    <div class="card-header">
        <svg class="icon me-2">
            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-list-numbered')); ?>"></use>
        </svg>
        <strong>Recent Transactions</strong>
        <small class="text-body-secondary ms-auto">Your latest wallet activity</small>
    </div>
    <div class="card-body p-0">
        <?php $__empty_1 = true; $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="list-group-item d-flex justify-content-between align-items-center border-0 border-bottom">
                <div class="d-flex align-items-center">
                    <div class="avatar avatar-md me-3
                        <?php if($transaction->type === 'deposit' || $transaction->type === 'transfer_in'): ?> bg-success-gradient
                        <?php elseif($transaction->type === 'withdrawal' || $transaction->type === 'transfer_out'): ?> bg-danger-gradient
                        <?php elseif($transaction->type === 'transfer_charge'): ?> bg-warning-gradient
                        <?php else: ?> bg-info-gradient <?php endif; ?>">
                        <svg class="icon text-white">
                            <?php if($transaction->type === 'deposit' || $transaction->type === 'transfer_in'): ?>
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-arrow-circle-bottom')); ?>"></use>
                            <?php elseif($transaction->type === 'withdrawal' || $transaction->type === 'transfer_out'): ?>
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-arrow-circle-top')); ?>"></use>
                            <?php elseif($transaction->type === 'transfer_charge'): ?>
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-dollar')); ?>"></use>
                            <?php else: ?>
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-swap-horizontal')); ?>"></use>
                            <?php endif; ?>
                        </svg>
                    </div>
                    <div>
                        <div class="fw-semibold">
                            <?php if($transaction->type === 'transfer_out'): ?>
                                Transfer Sent
                            <?php elseif($transaction->type === 'transfer_in'): ?>
                                Transfer Received
                            <?php elseif($transaction->type === 'transfer_charge'): ?>
                                Transfer Fee
                            <?php else: ?>
                                <?php echo e(ucfirst($transaction->type)); ?>

                            <?php endif; ?>
                        </div>
                        <div class="small text-body-secondary">
                            <svg class="icon icon-xs me-1">
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-clock')); ?>"></use>
                            </svg>
                            <?php echo e($transaction->created_at->diffForHumans()); ?>

                        </div>
                    </div>
                </div>
                <div class="text-end">
                    <div class="fw-semibold
                        <?php if($transaction->type === 'deposit' || $transaction->type === 'transfer_in'): ?> text-success
                        <?php elseif($transaction->type === 'transfer_charge'): ?> text-warning
                        <?php else: ?> text-danger <?php endif; ?>">
                        <?php if($transaction->type === 'deposit' || $transaction->type === 'transfer_in'): ?>
                            +<?php echo e(currency($transaction->amount)); ?>

                        <?php else: ?>
                            -<?php echo e(currency($transaction->amount)); ?>

                        <?php endif; ?>
                    </div>
                    <span class="badge
                        <?php if($transaction->status == 'approved'): ?> bg-success-gradient
                        <?php elseif($transaction->status == 'rejected'): ?> bg-danger-gradient
                        <?php elseif($transaction->status == 'pending'): ?> bg-warning-gradient
                        <?php else: ?> bg-secondary-gradient <?php endif; ?>">
                        <?php echo e(ucfirst($transaction->status)); ?>

                    </span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="p-4 text-center">
                <svg class="icon icon-3xl text-body-secondary mb-3">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-inbox')); ?>"></use>
                </svg>
                <h4 class="text-body-secondary">No transactions</h4>
                <p class="text-body-secondary">Get started by making your first deposit.</p>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deposit_funds')): ?>
                    <a href="<?php echo e(route('wallet.deposit')); ?>" class="btn btn-primary mt-2">
                        <svg class="icon me-1">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-plus')); ?>"></use>
                        </svg>
                        Make Deposit
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php if($recentTransactions->count() > 0): ?>
        <div class="card-footer">
            <a href="<?php echo e(route('wallet.transactions')); ?>" class="btn btn-outline-primary btn-sm">
                <svg class="icon me-1">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-list')); ?>"></use>
                </svg>
                View all transactions
            </a>
        </div>
    <?php endif; ?>
</div>

<!-- Account Information -->
<div class="card mb-4">
    <div class="card-header">
        <svg class="icon me-2">
            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-user')); ?>"></use>
        </svg>
        <strong>Account Information</strong>
        <small class="text-body-secondary ms-auto">Your account details and security status</small>
    </div>
    <div class="card-body p-0">
        <div class="list-group list-group-flush">
            <div class="list-group-item d-flex align-items-center">
                <div class="avatar avatar-sm bg-primary-gradient me-3">
                    <svg class="icon text-white icon-xs">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-envelope-closed')); ?>"></use>
                    </svg>
                </div>
                <div class="flex-grow-1">
                    <div class="fw-semibold">Email Address</div>
                    <div class="small text-body-secondary"><?php echo e($user->email); ?></div>
                </div>
                <?php if($user->email_verified_at): ?>
                    <span class="badge bg-success text-white rounded-pill">
                        <svg class="icon icon-xs me-1">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check-circle')); ?>"></use>
                        </svg>
                        Verified
                    </span>
                <?php else: ?>
                    <span class="badge bg-danger text-white rounded-pill">
                        <svg class="icon icon-xs me-1">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-x-circle')); ?>"></use>
                        </svg>
                        Unverified
                    </span>
                <?php endif; ?>
            </div>

            <div class="list-group-item d-flex align-items-center">
                <div class="avatar avatar-sm bg-info-gradient me-3">
                    <svg class="icon text-white icon-xs">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-shield-alt')); ?>"></use>
                    </svg>
                </div>
                <div class="flex-grow-1">
                    <div class="fw-semibold">Account Security</div>
                    <div class="small text-body-secondary">Email verification status</div>
                </div>
                <?php if($user->email_verified_at): ?>
                    <span class="badge bg-success text-white rounded-pill">
                        <svg class="icon icon-xs me-1">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check-circle')); ?>"></use>
                        </svg>
                        Secured
                    </span>
                <?php else: ?>
                    <span class="badge bg-warning text-dark rounded-pill">
                        <svg class="icon icon-xs me-1">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-warning')); ?>"></use>
                        </svg>
                        Needs Attention
                    </span>
                <?php endif; ?>
            </div>

            <div class="list-group-item d-flex align-items-center">
                <div class="avatar avatar-sm bg-secondary-gradient me-3">
                    <svg class="icon text-white icon-xs">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-mobile')); ?>"></use>
                    </svg>
                </div>
                <div class="flex-grow-1">
                    <div class="fw-semibold">Two-Factor Authentication</div>
                    <div class="small text-body-secondary">Additional security protection</div>
                </div>
                <?php if($user->two_factor_secret): ?>
                    <span class="badge bg-success text-white rounded-pill">
                        <svg class="icon icon-xs me-1">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-lock-locked')); ?>"></use>
                        </svg>
                        Enabled
                    </span>
                <?php else: ?>
                    <span class="badge bg-warning text-dark rounded-pill">
                        <svg class="icon icon-xs me-1">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-lock-unlocked')); ?>"></use>
                        </svg>
                        Disabled
                    </span>
                <?php endif; ?>
            </div>

            <div class="list-group-item d-flex align-items-center">
                <div class="avatar avatar-sm bg-success-gradient me-3">
                    <svg class="icon text-white icon-xs">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-wallet')); ?>"></use>
                    </svg>
                </div>
                <div class="flex-grow-1">
                    <div class="fw-semibold">Wallet Status</div>
                    <div class="small text-body-secondary">Current wallet access level</div>
                </div>
                <?php if($wallet->is_active): ?>
                    <span class="badge bg-success text-white rounded-pill">
                        <svg class="icon icon-xs me-1">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check-circle')); ?>"></use>
                        </svg>
                        Active
                    </span>
                <?php else: ?>
                    <span class="badge bg-danger text-white rounded-pill">
                        <svg class="icon icon-xs me-1">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-ban')); ?>"></use>
                        </svg>
                        Frozen
                    </span>
                <?php endif; ?>
            </div>

            <div class="list-group-item d-flex align-items-center">
                <div class="avatar avatar-sm bg-warning-gradient me-3">
                    <svg class="icon text-white icon-xs">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-chart-line')); ?>"></use>
                    </svg>
                </div>
                <div class="flex-grow-1">
                    <div class="fw-semibold">Transaction Activity</div>
                    <div class="small text-body-secondary">Total completed transactions</div>
                </div>
                <span class="badge bg-info text-white rounded-pill">
                    <?php echo e($totalTransactions); ?> Transactions
                </span>
            </div>

            <div class="list-group-item d-flex align-items-center">
                <div class="avatar avatar-sm bg-purple-gradient me-3">
                    <svg class="icon text-white icon-xs">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-calendar')); ?>"></use>
                    </svg>
                </div>
                <div class="flex-grow-1">
                    <div class="fw-semibold">Member Since</div>
                    <div class="small text-body-secondary">Account creation date</div>
                </div>
                <span class="text-body-secondary fw-semibold">
                    <?php echo e($user->created_at->format('M d, Y')); ?>

                </span>
            </div>
        </div>
    </div>
</div>

<!-- Monthly Transaction Summary -->
<?php if($monthlyTransactions->count() > 0): ?>
<div class="card mb-4">
    <div class="card-header">
        <svg class="icon me-2">
            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-chart-line')); ?>"></use>
        </svg>
        <strong>Monthly Transaction Summary</strong>
        <small class="text-body-secondary ms-auto">Your transaction activity over the past 6 months</small>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th scope="col">Month</th>
                        <th scope="col">Deposits</th>
                        <th scope="col">Withdrawals</th>
                        <th scope="col">Transactions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $monthlyTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthly): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="fw-semibold">
                                <?php echo e(date('M Y', mktime(0, 0, 0, $monthly->month, 1, $monthly->year))); ?>

                            </td>
                            <td class="text-success fw-semibold">
                                <?php echo e(currency($monthly->deposits)); ?>

                            </td>
                            <td class="text-danger fw-semibold">
                                <?php echo e(currency($monthly->withdrawals)); ?>

                            </td>
                            <td class="fw-semibold">
                                <?php echo e($monthly->count); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Bottom spacing for better visual layout -->
<div class="pb-5"></div>

<style>
/* Gradient backgrounds */
.bg-success-gradient {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
}

.bg-info-gradient {
    background: linear-gradient(135deg, #17a2b8 0%, #6f42c1 100%);
}

.bg-warning-gradient {
    background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);
}

.bg-danger-gradient {
    background: linear-gradient(135deg, #dc3545 0%, #e83e8c 100%);
}

.bg-purple-gradient {
    background: linear-gradient(135deg, #6f42c1 0%, #e83e8c 100%);
}

.bg-secondary-gradient {
    background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
}

/* Fix mobile overflow */
@media (max-width: 575px) {
    .row {
        --cui-gutter-x: 0.75rem;
    }
}

/* Welcome header improvements */
.card.border-0.shadow-sm {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.card.border-0.shadow-sm .card-title {
    color: white !important;
}

.card.border-0.shadow-sm .text-body-secondary {
    color: rgba(255, 255, 255, 0.8) !important;
}

/* Icon sizing */
.icon-2xl {
    width: 2rem;
    height: 2rem;
}

.icon-xl {
    width: 1.5rem;
    height: 1.5rem;
}

.icon-sm {
    width: 0.875rem;
    height: 0.875rem;
}

/* Avatar sizing */
.avatar-sm {
    width: 32px;
    height: 32px;
    border-radius: 8px;
}

.avatar-md {
    width: 40px;
    height: 40px;
    border-radius: 10px;
}

.avatar-xl {
    width: 64px;
    height: 64px;
    border-radius: 16px;
}

/* List group item padding fix for avatar spacing */
.list-group-item {
    padding: 1rem 1.25rem;
}

/* Transaction item improvements */
.transaction-item {
    transition: all 0.2s ease;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05) !important;
}

.transaction-item:hover {
    background-color: rgba(0, 123, 255, 0.02);
}

.transaction-item:last-child {
    border-bottom: none !important;
}

/* Badge improvements */
.badge.rounded-pill {
    font-size: 10px;
    font-weight: 500;
    padding: 4px 8px;
}

/* Empty state */
.empty-state .avatar-xl {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
}

/* Card header improvements */
.card-header.bg-white {
    padding: 1.25rem 1.5rem;
}

/* Quick actions button improvements */
.btn-purple {
    background: linear-gradient(135deg, #6f42c1 0%, #e83e8c 100%);
    border-color: #6f42c1;
    color: white;
}

.btn-purple:hover {
    background: linear-gradient(135deg, #5a32a3 0%, #d91a72 100%);
    border-color: #5a32a3;
    color: white;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\coreui_laravel_deploy\resources\views/dashboard.blade.php ENDPATH**/ ?>