<?php $__env->startSection('title', 'Packages'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h2 mb-2">Available Packages</h1>
                    <p class="text-muted">Choose the perfect package for your needs</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <form method="GET" action="<?php echo e(route('packages.index')); ?>" class="d-flex gap-2">
                <input type="text" name="search" class="form-control" placeholder="Search packages..."
                       value="<?php echo e(request('search')); ?>">
                <button type="submit" class="btn btn-outline-primary">
                    <svg class="icon">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-search')); ?>"></use>
                    </svg>
                </button>
            </form>
        </div>
        <div class="col-md-6">
            <div class="d-flex justify-content-md-end">
                <select class="form-select" onchange="location = this.value;" style="max-width: 250px;">
                    <option value="<?php echo e(route('packages.index')); ?>"
                            <?php echo e(!request('sort') ? 'selected' : ''); ?>>Sort by Default</option>
                    <option value="<?php echo e(route('packages.index', ['sort' => 'price_low'] + request()->query())); ?>"
                            <?php echo e(request('sort') == 'price_low' ? 'selected' : ''); ?>>Price: Low to High</option>
                    <option value="<?php echo e(route('packages.index', ['sort' => 'price_high'] + request()->query())); ?>"
                            <?php echo e(request('sort') == 'price_high' ? 'selected' : ''); ?>>Price: High to Low</option>
                    <option value="<?php echo e(route('packages.index', ['sort' => 'points_high'] + request()->query())); ?>"
                            <?php echo e(request('sort') == 'points_high' ? 'selected' : ''); ?>>Most Points</option>
                    <option value="<?php echo e(route('packages.index', ['sort' => 'name'] + request()->query())); ?>"
                            <?php echo e(request('sort') == 'name' ? 'selected' : ''); ?>>Name A-Z</option>
                </select>
            </div>
        </div>
    </div>

    <?php if($packages->count() > 0): ?>
        <div class="row">
            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100 package-card">
                        <div class="card-img-top-wrapper" style="height: 150px; overflow: hidden;">
                            <img src="<?php echo e($package->image_url); ?>" class="card-img-top" alt="<?php echo e($package->name); ?>"
                                 style="width: 100%; height: 100%; object-fit: cover;">
                        </div>
                        <div class="card-body d-flex flex-column p-3">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h6 class="card-title mb-0 fw-bold"><?php echo e($package->name); ?></h6>
                                <?php if($package->quantity_available !== null && $package->quantity_available <= 10): ?>
                                    <span class="badge bg-warning small">Limited</span>
                                <?php endif; ?>
                                <?php if(isset($package->meta_data['badge'])): ?>
                                    <span class="badge bg-info small"><?php echo e($package->meta_data['badge']); ?></span>
                                <?php endif; ?>
                            </div>

                            <p class="card-text text-muted small mb-2" style="line-height: 1.3;"><?php echo e(Str::limit($package->short_description, 80)); ?></p>

                            <div class="row mb-2">
                                <div class="col-6">
                                    <div class="text-center p-1 bg-light rounded">
                                        <div class="fw-bold text-primary mb-0"><?php echo e($package->formatted_price); ?></div>
                                        <small class="text-muted" style="font-size: 0.7rem;">Price</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="text-center p-1 bg-light rounded">
                                        <div class="fw-bold text-success mb-0"><?php echo e(number_format($package->points_awarded)); ?></div>
                                        <small class="text-muted" style="font-size: 0.7rem;">Points</small>
                                    </div>
                                </div>
                            </div>

                            <?php if(isset($package->meta_data['features'])): ?>
                                <ul class="list-unstyled mb-2" style="font-size: 0.8rem;">
                                    <?php $__currentLoopData = array_slice($package->meta_data['features'], 0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="d-flex align-items-center mb-1">
                                            <svg class="icon text-success me-1 flex-shrink-0" style="width: 10px; height: 10px;">
                                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check')); ?>"></use>
                                            </svg>
                                            <span style="line-height: 1.2;"><?php echo e(Str::limit($feature, 35)); ?></span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($package->meta_data['features']) > 2): ?>
                                        <li class="text-muted small">
                                            +<?php echo e(count($package->meta_data['features']) - 2); ?> more
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            <?php endif; ?>

                            <div class="mt-auto">
                                <?php if($package->quantity_available !== null): ?>
                                    <div class="mb-2">
                                        <small class="text-muted" style="font-size: 0.75rem;">
                                            <?php if($package->quantity_available > 0): ?>
                                                <?php echo e($package->quantity_available); ?> left
                                            <?php else: ?>
                                                Out of stock
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                <?php endif; ?>

                                <div class="d-grid gap-1">
                                    <a href="<?php echo e(route('packages.show', $package)); ?>" class="btn btn-outline-primary btn-sm">
                                        View Details
                                    </a>
                                    <?php if($package->isAvailable()): ?>
                                        <?php if(in_array($package->id, $cartPackageIds)): ?>
                                            <button class="btn btn-success btn-sm" disabled>
                                                <svg class="icon me-1" style="width: 14px; height: 14px;">
                                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check')); ?>"></use>
                                                </svg>
                                                In Cart
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-primary btn-sm add-to-cart-btn" data-package-id="<?php echo e($package->id); ?>">
                                                <svg class="icon me-1" style="width: 14px; height: 14px;">
                                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-cart')); ?>"></use>
                                                </svg>
                                                Add to Cart
                                            </button>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <button class="btn btn-secondary btn-sm" disabled>
                                            Unavailable
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row">
            <div class="col-12">
                <?php echo e($packages->appends(request()->query())->links()); ?>

            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-12">
                <div class="text-center py-5">
                    <svg class="icon icon-xxl text-muted mb-3">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-inbox')); ?>"></use>
                    </svg>
                    <h5 class="text-muted">No packages found</h5>
                    <p class="text-muted">
                        <?php if(request('search')): ?>
                            No packages match your search "<?php echo e(request('search')); ?>".
                            <a href="<?php echo e(route('packages.index')); ?>">View all packages</a>
                        <?php else: ?>
                            There are no packages available at the moment.
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Bottom spacing for better visual layout -->
<div class="pb-5"></div>

<style>
.package-card {
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}

.package-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.card-img-top-wrapper {
    position: relative;
}

.add-to-cart-btn {
    transition: all 0.2s ease-in-out;
}

.add-to-cart-btn:hover {
    transform: translateY(-1px);
}
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\coreui_laravel_deploy\resources\views/packages/index.blade.php ENDPATH**/ ?>