<?php if($paginator->hasPages()): ?>
    <nav aria-label="Pagination Navigation">
        <ul class="pagination pagination-sm justify-content-center mb-0">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                    <span class="page-link">
                        <svg class="icon">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-chevron-left')); ?>"></use>
                        </svg>
                    </span>
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                        <svg class="icon">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-chevron-left')); ?>"></use>
                        </svg>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li class="page-item disabled" aria-disabled="true">
                        <span class="page-link"><?php echo e($element); ?></span>
                    </li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="page-item active" aria-current="page">
                                <span class="page-link fw-bold"><?php echo e($page); ?></span>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                        <svg class="icon">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-chevron-right')); ?>"></use>
                        </svg>
                    </a>
                </li>
            <?php else: ?>
                <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    <span class="page-link">
                        <svg class="icon">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-chevron-right')); ?>"></use>
                        </svg>
                    </span>
                </li>
            <?php endif; ?>
        </ul>

        
        <div class="d-flex justify-content-center mt-3">
            <small class="text-muted">
                Showing <?php echo e($paginator->firstItem() ?? 0); ?> to <?php echo e($paginator->lastItem() ?? 0); ?> of <?php echo e($paginator->total()); ?> results
            </small>
        </div>
    </nav>
<?php endif; ?><?php /**PATH C:\laragon\www\coreui_laravel_deploy\resources\views/vendor/pagination/coreui.blade.php ENDPATH**/ ?>