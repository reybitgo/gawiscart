<div class="sidebar sidebar-fixed border-end" id="sidebar">
    <div class="sidebar-header border-bottom">
        <div class="sidebar-brand">
            <!-- Dark theme logos (default) -->
            <img class="sidebar-brand-full logo-dark" src="<?php echo e(asset('coreui-template/assets/brand/gawis_logo.png')); ?>" width="110" height="39" alt="<?php echo e(config('app.name', 'Gawis iHerbal')); ?> Logo" />
            <img class="sidebar-brand-narrow logo-dark" src="<?php echo e(asset('coreui-template/assets/brand/gawis.png')); ?>" width="32" height="32" alt="<?php echo e(config('app.name', 'Gawis iHerbal')); ?> Logo" />
            <!-- Light theme logos -->
            <img class="sidebar-brand-full logo-light" src="<?php echo e(asset('coreui-template/assets/brand/gawis_logo_light.png')); ?>" width="110" height="39" alt="<?php echo e(config('app.name', 'Gawis iHerbal')); ?> Logo" />
            <img class="sidebar-brand-narrow logo-light" src="<?php echo e(asset('coreui-template/assets/brand/gawis_light.png')); ?>" width="32" height="32" alt="<?php echo e(config('app.name', 'Gawis iHerbal')); ?> Logo" />
        </div>
        <button class="btn-close d-lg-none" type="button" aria-label="Close" onclick='coreui.Sidebar.getInstance(document.querySelector("#sidebar")).toggle()'></button>
    </div>
    <ul class="sidebar-nav" data-coreui="navigation" data-simplebar="">
        <!-- Dashboard -->
        <li class="nav-item">
            <a class="nav-link<?php echo e(Request::routeIs('dashboard') ? ' active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                <svg class="nav-icon">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-speedometer')); ?>"></use>
                </svg>
                <span>Dashboard</span>
            </a>
        </li>

        <?php if(auth()->user()->hasRole('admin')): ?>
            <!-- Admin Section -->
            <li class="nav-title">Administration</li>
            <li class="nav-item">
                <a class="nav-link<?php echo e(Request::routeIs('admin.dashboard') ? ' active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                    <svg class="nav-icon">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-chart-pie')); ?>"></use>
                    </svg>
                    <span>Admin Dashboard</span>
                </a>
            </li>

            <!-- Admin Management Group -->
            <li class="nav-group">
                <a class="nav-link nav-group-toggle<?php echo e(Request::routeIs('admin.*') && !Request::routeIs('admin.dashboard') ? ' active' : ''); ?>" href="#">
                    <svg class="nav-icon">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-puzzle')); ?>"></use>
                    </svg>
                    <span>Management</span>
                </a>
                <ul class="nav-group-items compact">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('wallet_management')): ?>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Request::routeIs('admin.wallet.*') ? ' active' : ''); ?>" href="<?php echo e(route('admin.wallet.management')); ?>">
                            <span class="nav-icon">
                                <span class="nav-icon-bullet"></span>
                            </span>
                            Wallet Management
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transaction_approval')): ?>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Request::routeIs('admin.transaction.*') ? ' active' : ''); ?>" href="<?php echo e(route('admin.transaction.approval')); ?>">
                            <span class="nav-icon">
                                <span class="nav-icon-bullet"></span>
                            </span>
                            Transaction Approval
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Request::routeIs('admin.users') ? ' active' : ''); ?>" href="<?php echo e(route('admin.users')); ?>">
                            <span class="nav-icon">
                                <span class="nav-icon-bullet"></span>
                            </span>
                            User Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Request::routeIs('admin.packages.*') ? ' active' : ''); ?>" href="<?php echo e(route('admin.packages.index')); ?>">
                            <span class="nav-icon">
                                <span class="nav-icon-bullet"></span>
                            </span>
                            Package Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Request::routeIs('admin.orders.*') ? ' active' : ''); ?>" href="<?php echo e(route('admin.orders.index')); ?>">
                            <span class="nav-icon">
                                <span class="nav-icon-bullet"></span>
                            </span>
                            Order Management
                            <?php
                                $paidOrdersCount = \App\Models\Order::where('status', 'paid')->count();
                            ?>
                            <?php if($paidOrdersCount > 0): ?>
                                <span class="badge badge-sm bg-info ms-auto"><?php echo e($paidOrdersCount); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Request::routeIs('admin.returns.*') ? ' active' : ''); ?>" href="<?php echo e(route('admin.returns.index')); ?>">
                            <span class="nav-icon">
                                <span class="nav-icon-bullet"></span>
                            </span>
                            Return Requests
                            <?php
                                $pendingReturnsCount = \App\Models\ReturnRequest::where('status', 'pending')->count();
                            ?>
                            <?php if($pendingReturnsCount > 0): ?>
                                <span class="badge badge-sm bg-warning ms-auto"><?php echo e($pendingReturnsCount); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Request::routeIs('admin.settings.*') ? ' active' : ''); ?>" href="<?php echo e(route('admin.settings.index')); ?>">
                            <span class="nav-icon">
                                <span class="nav-icon-bullet"></span>
                            </span>
                            Application Settings
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('system_settings')): ?>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Request::routeIs('admin.reports*') ? ' active' : ''); ?>" href="<?php echo e(route('admin.reports')); ?>">
                            <span class="nav-icon">
                                <span class="nav-icon-bullet"></span>
                            </span>
                            Reports & Analytics
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Request::routeIs('admin.logs') ? ' active' : ''); ?>" href="<?php echo e(route('admin.logs')); ?>">
                            <span class="nav-icon">
                                <span class="nav-icon-bullet"></span>
                            </span>
                            System Logs
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Request::routeIs('admin.system.*') ? ' active' : ''); ?>" href="<?php echo e(route('admin.system.settings')); ?>">
                            <span class="nav-icon">
                                <span class="nav-icon-bullet"></span>
                            </span>
                            System Settings
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>

        <!-- E-Wallet Section -->
        <li class="nav-title">E-Wallet</li>
        <li class="nav-group">
            <a class="nav-link nav-group-toggle<?php echo e(Request::routeIs('wallet.*') ? ' active' : ''); ?>" href="#">
                <svg class="nav-icon">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-wallet')); ?>"></use>
                </svg>
                <span>Wallet Operations</span>
            </a>
            <ul class="nav-group-items compact">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deposit_funds')): ?>
                <li class="nav-item">
                    <a class="nav-link<?php echo e(Request::routeIs('wallet.deposit*') ? ' active' : ''); ?>" href="<?php echo e(route('wallet.deposit')); ?>">
                        <span class="nav-icon">
                            <span class="nav-icon-bullet"></span>
                        </span>
                        Deposit Funds
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transfer_funds')): ?>
                <li class="nav-item">
                    <a class="nav-link<?php echo e(Request::routeIs('wallet.transfer*') ? ' active' : ''); ?>" href="<?php echo e(route('wallet.transfer')); ?>">
                        <span class="nav-icon">
                            <span class="nav-icon-bullet"></span>
                        </span>
                        Transfer Funds
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('withdraw_funds')): ?>
                <li class="nav-item">
                    <a class="nav-link<?php echo e(Request::routeIs('wallet.withdraw*') ? ' active' : ''); ?>" href="<?php echo e(route('wallet.withdraw')); ?>">
                        <span class="nav-icon">
                            <span class="nav-icon-bullet"></span>
                        </span>
                        Withdraw Funds
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_transactions')): ?>
                <li class="nav-item">
                    <a class="nav-link<?php echo e(Request::routeIs('wallet.transactions*') ? ' active' : ''); ?>" href="<?php echo e(route('wallet.transactions')); ?>">
                        <span class="nav-icon">
                            <span class="nav-icon-bullet"></span>
                        </span>
                        Transaction History
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </li>

        <!-- Member Actions Section -->
        <li class="nav-title">Member Actions</li>
        <li class="nav-item">
            <a class="nav-link<?php echo e(Request::routeIs('member.register.*') ? ' active' : ''); ?>" href="<?php echo e(route('member.register.show')); ?>">
                <svg class="nav-icon">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-user-follow')); ?>"></use>
                </svg>
                <span>Register New Member</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link<?php echo e(Request::routeIs('referral.*') ? ' active' : ''); ?>" href="<?php echo e(route('referral.index')); ?>">
                <svg class="nav-icon">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-share-alt')); ?>"></use>
                </svg>
                <span>My Referral Link</span>
            </a>
        </li>

        <!-- E-commerce Section -->
        <li class="nav-title">E-commerce</li>
        <li class="nav-group">
            <a class="nav-link nav-group-toggle<?php echo e(Request::routeIs('packages.*') ? ' active' : ''); ?>" href="#">
                <svg class="nav-icon">
                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-cart')); ?>"></use>
                </svg>
                <span>Shopping</span>
            </a>
            <ul class="nav-group-items compact">
                <li class="nav-item">
                    <a class="nav-link<?php echo e(Request::routeIs('packages.index') ? ' active' : ''); ?>" href="<?php echo e(route('packages.index')); ?>">
                        <span class="nav-icon">
                            <span class="nav-icon-bullet"></span>
                        </span>
                        Browse Packages
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link<?php echo e(Request::routeIs('cart.*') ? ' active' : ''); ?>" href="<?php echo e(route('cart.index')); ?>">
                        <span class="nav-icon">
                            <span class="nav-icon-bullet"></span>
                        </span>
                        Shopping Cart
                        <?php
                            $cartCount = app('App\Services\CartService')->getItemCount();
                        ?>
                        <?php if($cartCount > 0): ?>
                            <span class="badge bg-primary ms-auto"><?php echo e($cartCount); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link<?php echo e(Request::routeIs('orders.*') ? ' active' : ''); ?>" href="<?php echo e(route('orders.index')); ?>">
                        <span class="nav-icon">
                            <span class="nav-icon-bullet"></span>
                        </span>
                        Order History
                        <?php
                            $userOrdersCount = auth()->user() ? App\Models\Order::where('user_id', auth()->id())->count() : 0;
                        ?>
                        <?php if($userOrdersCount > 0): ?>
                            <span class="badge bg-success ms-auto"><?php echo e($userOrdersCount); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </li>
    </ul>
    <div class="sidebar-footer border-top d-none d-lg-flex">
        <button class="sidebar-toggler" type="button" data-coreui-toggle="unfoldable"></button>
    </div>
</div><?php /**PATH C:\laragon\www\coreui_laravel_deploy\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>