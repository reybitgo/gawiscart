<?php $__env->startSection('title', 'Package Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Packages</h5>
                        <a href="<?php echo e(route('admin.packages.create')); ?>" class="btn btn-primary">
                            <svg class="icon me-2">
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-plus')); ?>"></use>
                            </svg>
                            Add New Package
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if($packages->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>Points</th>
                                        <th>Quantity</th>
                                        <th>Status</th>
                                        <th>Sort</th>
                                        <th class="text-center">Plan</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="<?php echo e($package->trashed() ? 'table-secondary' : ''); ?>">
                                            <td>
                                                <img src="<?php echo e($package->image_url); ?>" alt="<?php echo e($package->name); ?>"
                                                     class="rounded" style="width: 50px; height: 50px; object-fit: cover;">
                                            </td>
                                            <td>
                                                <div>
                                                    <strong><?php echo e($package->name); ?></strong>
                                                    <?php if($package->trashed()): ?>
                                                        <span class="badge bg-secondary ms-2">Deleted</span>
                                                    <?php endif; ?>
                                                </div>
                                                <small class="text-muted"><?php echo e(Str::limit($package->short_description, 50)); ?></small>
                                            </td>
                                            <td><?php echo e($package->formatted_price); ?></td>
                                            <td>
                                                <span class="badge bg-info"><?php echo e(number_format($package->points_awarded)); ?> pts</span>
                                            </td>
                                            <td>
                                                <?php if($package->quantity_available === null): ?>
                                                    <span class="badge bg-success">Unlimited</span>
                                                <?php else: ?>
                                                    <span class="badge bg-<?php echo e($package->quantity_available > 0 ? 'success' : 'danger'); ?>">
                                                        <?php echo e($package->quantity_available); ?>

                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if(!$package->trashed()): ?>
                                                    <span class="badge bg-<?php echo e($package->is_active ? 'success' : 'warning'); ?>">
                                                        <?php echo e($package->is_active ? 'Active' : 'Inactive'); ?>

                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Deleted</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($package->sort_order); ?></td>
                                            <td class="text-center">
                                                <?php if($package->is_mlm_package): ?>
                                                    <svg class="icon text-success">
                                                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-check')); ?>"></use>
                                                    </svg>
                                                <?php else: ?>
                                                    <span class="text-muted">—</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <?php if(!$package->trashed()): ?>
                                                        <a href="<?php echo e(route('admin.packages.show', $package)); ?>"
                                                           class="btn btn-sm btn-outline-info" title="View">
                                                            <svg class="icon">
                                                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-magnifying-glass')); ?>"></use>
                                                            </svg>
                                                        </a>
                                                        <a href="<?php echo e(route('admin.packages.edit', $package)); ?>"
                                                           class="btn btn-sm btn-outline-primary" title="Edit">
                                                            <svg class="icon">
                                                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-pencil')); ?>"></use>
                                                            </svg>
                                                        </a>
                                                        <form method="POST" action="<?php echo e(route('admin.packages.toggle-status', $package)); ?>" class="d-inline">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" class="btn btn-sm btn-outline-<?php echo e($package->is_active ? 'warning' : 'success'); ?>"
                                                                    title="<?php echo e($package->is_active ? 'Deactivate' : 'Activate'); ?>">
                                                                <svg class="icon">
                                                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-' . ($package->is_active ? 'ban' : 'check') . '')); ?>"></use>
                                                                </svg>
                                                            </button>
                                                        </form>
                                                        <?php if($package->canBeDeleted()): ?>
                                                            <button type="button" class="btn btn-sm btn-outline-danger" title="Delete"
                                                                    data-coreui-toggle="modal" data-coreui-target="#deleteModal"
                                                                    onclick="setDeletePackage('<?php echo e($package->id); ?>', '<?php echo e($package->name); ?>', '<?php echo e(route('admin.packages.destroy', $package)); ?>')">
                                                                <svg class="icon">
                                                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-trash')); ?>"></use>
                                                                </svg>
                                                            </button>
                                                        <?php else: ?>
                                                            <button type="button" class="btn btn-sm btn-outline-secondary" disabled title="Cannot delete - has been purchased">
                                                                <svg class="icon">
                                                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-lock-locked')); ?>"></use>
                                                                </svg>
                                                            </button>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <?php echo e($packages->links()); ?>

                    <?php else: ?>
                        <div class="text-center py-5">
                            <svg class="icon icon-xxl text-muted mb-3">
                                <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-inbox')); ?>"></use>
                            </svg>
                            <h5 class="text-muted">No packages found</h5>
                            <p class="text-muted">Get started by creating your first package.</p>
                            <a href="<?php echo e(route('admin.packages.create')); ?>" class="btn btn-primary">
                                <svg class="icon me-2">
                                    <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-plus')); ?>"></use>
                                </svg>
                                Create Package
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">
                    <svg class="icon text-danger me-2">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-warning')); ?>"></use>
                    </svg>
                    Confirm Package Deletion
                </h5>
                <button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="flex-shrink-0">
                        <svg class="icon icon-xl text-danger">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-trash')); ?>"></use>
                        </svg>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <h6 class="mb-1">Are you sure you want to delete this package?</h6>
                        <p class="text-muted mb-0">You are about to delete <strong id="packageName"></strong>. This action cannot be undone.</p>
                    </div>
                </div>
                <div class="alert alert-danger mb-0">
                    <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-warning')); ?>"></use>
                    </svg>
                    <strong>Warning:</strong> This will permanently remove the package and all its associated data.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-coreui-dismiss="modal">
                    <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-x')); ?>"></use>
                    </svg>
                    Cancel
                </button>
                <form id="deleteForm" method="POST" action="" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">
                        <svg class="icon me-2">
                            <use xlink:href="<?php echo e(asset('coreui-template/vendors/@coreui/icons/svg/free.svg#cil-trash')); ?>"></use>
                        </svg>
                        Delete Package
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function setDeletePackage(packageId, packageName, actionUrl) {
    document.getElementById('packageName').textContent = packageName;
    document.getElementById('deleteForm').action = actionUrl;
}
</script>

<!-- Bottom spacing for better visual layout -->
<div class="pb-5"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\coreui_laravel_deploy\resources\views/admin/packages/index.blade.php ENDPATH**/ ?>