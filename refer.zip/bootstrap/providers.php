<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\CustomAuthServiceProvider::class,
    App\Providers\FortifyServiceProvider::class,
];
